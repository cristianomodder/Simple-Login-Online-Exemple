package com.mycompany.myapp;
/*Créditos: Cristiano Modder*/
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.graphics.*;
import static android.view.ViewGroup.LayoutParams.*;

public class MainActivity extends Activity { 

    public LinearLayout linear1;
    public LinearLayout linear2;
	public LinearLayout linear_space0;
	public LinearLayout linear_space1;
	
	public TextView x_texto;
	
	public EditText usuario;
	public EditText senha;
	
	public Button logar;
	
	public int Screen_Pixel(int id){
		if (id == 0){
		    return getResources().getDisplayMetrics().widthPixels;
		}
		if (id == 1) {
			return getResources().getDisplayMetrics().heightPixels;
		}
		return 999;
	}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		
		this.linear1 = new LinearLayout(this);
		this.linear1.setLayoutParams(new LinearLayout.LayoutParams(Screen_Pixel(0), Screen_Pixel(1)));
		this.linear1.setOrientation(LinearLayout.VERTICAL);
		this.linear1.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
		
		this.linear2 = new LinearLayout(this);
		this.linear2.setLayoutParams(new LinearLayout.LayoutParams(Screen_Pixel(0) / 2, LinearLayout.LayoutParams.WRAP_CONTENT));
		this.linear2.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
		this.linear2.setOrientation(LinearLayout.VERTICAL);
		
		this.linear_space0 = new LinearLayout(this);
		this.linear_space0.setLayoutParams(new LinearLayout.LayoutParams(Screen_Pixel(0) / 2, Screen_Pixel(1)/15));
		this.linear_space0.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
		this.linear_space0.setOrientation(LinearLayout.VERTICAL);
		
		this.usuario = new EditText(this);
		this.usuario.setHint("Username");
		this.usuario.setHintTextColor(Color.GRAY);
		this.usuario.setTextColor(Color.GRAY);
		this.usuario.setBackgroundColor(Color.WHITE);
		
        this.senha = new EditText(this);
		this.senha.setHint("Password");
		this.senha.setHintTextColor(Color.GRAY);
		this.senha.setTextColor(Color.GRAY);
		this.senha.setBackgroundColor(Color.WHITE);
		
		this.logar = new Button(this);
		this.logar.setLayoutParams(new LinearLayout.LayoutParams(230, 70));
		this.logar.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
		this.logar.setText("Logar");
		this.logar.setPadding(0,0,0,0);
		this.logar.setTextColor(Color.WHITE);
		this.logar.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
						if(usuario.getText().toString().isEmpty()){
							usuario.setError("Usuario vazio ?");
						}
						if(senha.getText().toString().isEmpty()){
							senha.setError("Senha vazia ?");
						}
						if (!usuario.getText().toString().isEmpty() && !senha.getText().toString().isEmpty()) {
						Toast.makeText(getBaseContext(), "Logando... !", 1).show();
						new Conect(MainActivity.this).execute(usuario.getText().toString(), senha.getText().toString());
		                }
			}
		});
		
		this.linear_space1 = new LinearLayout(this);
		this.linear_space1.setLayoutParams(new LinearLayout.LayoutParams(Screen_Pixel(0) / 2, Screen_Pixel(1)/15));
		this.linear_space1.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
		this.linear_space1.setOrientation(LinearLayout.VERTICAL);
		
		this.Background();
		
		this.linear1.addView(this.linear2);
		this.NewText("L o g i n  E x e m p l e", linear2, Color.BLACK, 23);
		this.linear2.addView(this.linear_space0);
		this.linear2.addView(this.usuario);
		this.linear2.addView(this.senha);
		this.linear2.addView(this.logar);
		this.linear2.addView(this.linear_space1);
		this.NewText("Copyright © Cristiano Modder", linear1, Color.GRAY , 0);
		this.setContentView(this.linear1);
    }
	private void NewText(String texto, LinearLayout id, int cor, int size){
		this.x_texto = new TextView(this);
		if (size > 0){
		this.x_texto.setTextSize(size);
		//this.x_texto.setTypeface(null, Typeface.BOLD);
		}
		this.x_texto.setText(texto);
		this.x_texto.setTextColor(cor);
		this.x_texto.setPadding(0,0,0,0);
		this.x_texto.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
		id.addView(this.x_texto);
	}
	private void Background(){
		android.graphics.drawable.GradientDrawable JCJFBHJ = new android.graphics.drawable.GradientDrawable();
		JCJFBHJ.setColor(Color.parseColor("#FFFFFFFF"));
		JCJFBHJ.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		this.linear2.setBackground(JCJFBHJ);
		if(Build.VERSION.SDK_INT >= 21) {
        this.linear2.setElevation(21f);
		}
		
		android.graphics.drawable.GradientDrawable FIIJCDC = new android.graphics.drawable.GradientDrawable();
		FIIJCDC.setColor(Color.parseColor("#FF000000"));
		FIIJCDC.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		this.logar.setBackground(FIIJCDC);
	}
}
